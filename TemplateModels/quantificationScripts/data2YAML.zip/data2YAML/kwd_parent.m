function result = kwd_parent()
    result = 'parent';
end